window.SMK_CONFIG = {
  supabaseUrl: 'https://ivtmkwmglanunrdezxmo.supabase.co',
  supabaseAnonKey: 'sb_publishable_4nkZcYarvhZIy8nN25HJiQ_inX0lJzW'
};
